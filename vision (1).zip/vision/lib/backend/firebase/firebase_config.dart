import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAH3nIvG_FB80Z8a-d-dVcbGBvZUeS0itY",
            authDomain: "staff-357a4.firebaseapp.com",
            projectId: "staff-357a4",
            storageBucket: "staff-357a4.appspot.com",
            messagingSenderId: "358012222125",
            appId: "1:358012222125:web:53747c1f35ac404e80a424",
            measurementId: "G-DHV46CEPXN"));
  } else {
    await Firebase.initializeApp();
  }
}
