// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReferenceFromJsonStruct extends FFFirebaseStruct {
  ReferenceFromJsonStruct({
    DocumentReference? referenceID,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _referenceID = referenceID,
        super(firestoreUtilData);

  // "referenceID" field.
  DocumentReference? _referenceID;
  DocumentReference? get referenceID => _referenceID;
  set referenceID(DocumentReference? val) => _referenceID = val;
  bool hasReferenceID() => _referenceID != null;

  static ReferenceFromJsonStruct fromMap(Map<String, dynamic> data) =>
      ReferenceFromJsonStruct(
        referenceID: data['referenceID'] as DocumentReference?,
      );

  static ReferenceFromJsonStruct? maybeFromMap(dynamic data) => data is Map
      ? ReferenceFromJsonStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'referenceID': _referenceID,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'referenceID': serializeParam(
          _referenceID,
          ParamType.DocumentReference,
        ),
      }.withoutNulls;

  static ReferenceFromJsonStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      ReferenceFromJsonStruct(
        referenceID: deserializeParam(
          data['referenceID'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['results'],
        ),
      );

  @override
  String toString() => 'ReferenceFromJsonStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ReferenceFromJsonStruct && referenceID == other.referenceID;
  }

  @override
  int get hashCode => const ListEquality().hash([referenceID]);
}

ReferenceFromJsonStruct createReferenceFromJsonStruct({
  DocumentReference? referenceID,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ReferenceFromJsonStruct(
      referenceID: referenceID,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ReferenceFromJsonStruct? updateReferenceFromJsonStruct(
  ReferenceFromJsonStruct? referenceFromJson, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    referenceFromJson
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addReferenceFromJsonStructData(
  Map<String, dynamic> firestoreData,
  ReferenceFromJsonStruct? referenceFromJson,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (referenceFromJson == null) {
    return;
  }
  if (referenceFromJson.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && referenceFromJson.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final referenceFromJsonData =
      getReferenceFromJsonFirestoreData(referenceFromJson, forFieldValue);
  final nestedData =
      referenceFromJsonData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = referenceFromJson.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getReferenceFromJsonFirestoreData(
  ReferenceFromJsonStruct? referenceFromJson, [
  bool forFieldValue = false,
]) {
  if (referenceFromJson == null) {
    return {};
  }
  final firestoreData = mapToFirestore(referenceFromJson.toMap());

  // Add any Firestore field values
  referenceFromJson.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getReferenceFromJsonListFirestoreData(
  List<ReferenceFromJsonStruct>? referenceFromJsons,
) =>
    referenceFromJsons
        ?.map((e) => getReferenceFromJsonFirestoreData(e, true))
        .toList() ??
    [];
