// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GameConnectedStruct extends FFFirebaseStruct {
  GameConnectedStruct({
    String? gameConnectedName,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _gameConnectedName = gameConnectedName,
        super(firestoreUtilData);

  // "gameConnectedName" field.
  String? _gameConnectedName;
  String get gameConnectedName => _gameConnectedName ?? '';
  set gameConnectedName(String? val) => _gameConnectedName = val;
  bool hasGameConnectedName() => _gameConnectedName != null;

  static GameConnectedStruct fromMap(Map<String, dynamic> data) =>
      GameConnectedStruct(
        gameConnectedName: data['gameConnectedName'] as String?,
      );

  static GameConnectedStruct? maybeFromMap(dynamic data) => data is Map
      ? GameConnectedStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'gameConnectedName': _gameConnectedName,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'gameConnectedName': serializeParam(
          _gameConnectedName,
          ParamType.String,
        ),
      }.withoutNulls;

  static GameConnectedStruct fromSerializableMap(Map<String, dynamic> data) =>
      GameConnectedStruct(
        gameConnectedName: deserializeParam(
          data['gameConnectedName'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'GameConnectedStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is GameConnectedStruct &&
        gameConnectedName == other.gameConnectedName;
  }

  @override
  int get hashCode => const ListEquality().hash([gameConnectedName]);
}

GameConnectedStruct createGameConnectedStruct({
  String? gameConnectedName,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    GameConnectedStruct(
      gameConnectedName: gameConnectedName,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

GameConnectedStruct? updateGameConnectedStruct(
  GameConnectedStruct? gameConnected, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    gameConnected
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addGameConnectedStructData(
  Map<String, dynamic> firestoreData,
  GameConnectedStruct? gameConnected,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (gameConnected == null) {
    return;
  }
  if (gameConnected.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && gameConnected.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final gameConnectedData =
      getGameConnectedFirestoreData(gameConnected, forFieldValue);
  final nestedData =
      gameConnectedData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = gameConnected.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getGameConnectedFirestoreData(
  GameConnectedStruct? gameConnected, [
  bool forFieldValue = false,
]) {
  if (gameConnected == null) {
    return {};
  }
  final firestoreData = mapToFirestore(gameConnected.toMap());

  // Add any Firestore field values
  gameConnected.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getGameConnectedListFirestoreData(
  List<GameConnectedStruct>? gameConnecteds,
) =>
    gameConnecteds
        ?.map((e) => getGameConnectedFirestoreData(e, true))
        .toList() ??
    [];
