import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ButterflyRecord extends FirestoreRecord {
  ButterflyRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Level1" field.
  List<int>? _level1;
  List<int> get level1 => _level1 ?? const [];
  bool hasLevel1() => _level1 != null;

  // "Level2" field.
  List<int>? _level2;
  List<int> get level2 => _level2 ?? const [];
  bool hasLevel2() => _level2 != null;

  void _initializeFields() {
    _level1 = getDataList(snapshotData['Level1']);
    _level2 = getDataList(snapshotData['Level2']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Butterfly');

  static Stream<ButterflyRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ButterflyRecord.fromSnapshot(s));

  static Future<ButterflyRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ButterflyRecord.fromSnapshot(s));

  static ButterflyRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ButterflyRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ButterflyRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ButterflyRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ButterflyRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ButterflyRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createButterflyRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class ButterflyRecordDocumentEquality implements Equality<ButterflyRecord> {
  const ButterflyRecordDocumentEquality();

  @override
  bool equals(ButterflyRecord? e1, ButterflyRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.level1, e2?.level1) &&
        listEquality.equals(e1?.level2, e2?.level2);
  }

  @override
  int hash(ButterflyRecord? e) =>
      const ListEquality().hash([e?.level1, e?.level2]);

  @override
  bool isValidKey(Object? o) => o is ButterflyRecord;
}
