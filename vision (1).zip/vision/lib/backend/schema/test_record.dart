import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TestRecord extends FirestoreRecord {
  TestRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "DifficultyLevel" field.
  int? _difficultyLevel;
  int get difficultyLevel => _difficultyLevel ?? 0;
  bool hasDifficultyLevel() => _difficultyLevel != null;

  // "PatternNumber" field.
  int? _patternNumber;
  int get patternNumber => _patternNumber ?? 0;
  bool hasPatternNumber() => _patternNumber != null;

  // "PatternElements" field.
  List<int>? _patternElements;
  List<int> get patternElements => _patternElements ?? const [];
  bool hasPatternElements() => _patternElements != null;

  void _initializeFields() {
    _difficultyLevel = castToType<int>(snapshotData['DifficultyLevel']);
    _patternNumber = castToType<int>(snapshotData['PatternNumber']);
    _patternElements = getDataList(snapshotData['PatternElements']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('test');

  static Stream<TestRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TestRecord.fromSnapshot(s));

  static Future<TestRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TestRecord.fromSnapshot(s));

  static TestRecord fromSnapshot(DocumentSnapshot snapshot) => TestRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TestRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TestRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TestRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TestRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTestRecordData({
  int? difficultyLevel,
  int? patternNumber,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'DifficultyLevel': difficultyLevel,
      'PatternNumber': patternNumber,
    }.withoutNulls,
  );

  return firestoreData;
}

class TestRecordDocumentEquality implements Equality<TestRecord> {
  const TestRecordDocumentEquality();

  @override
  bool equals(TestRecord? e1, TestRecord? e2) {
    const listEquality = ListEquality();
    return e1?.difficultyLevel == e2?.difficultyLevel &&
        e1?.patternNumber == e2?.patternNumber &&
        listEquality.equals(e1?.patternElements, e2?.patternElements);
  }

  @override
  int hash(TestRecord? e) => const ListEquality()
      .hash([e?.difficultyLevel, e?.patternNumber, e?.patternElements]);

  @override
  bool isValidKey(Object? o) => o is TestRecord;
}
