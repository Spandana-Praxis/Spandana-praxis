import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ResultsRecord extends FirestoreRecord {
  ResultsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "gameName" field.
  String? _gameName;
  String get gameName => _gameName ?? '';
  bool hasGameName() => _gameName != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "misses" field.
  List<int>? _misses;
  List<int> get misses => _misses ?? const [];
  bool hasMisses() => _misses != null;

  // "inaccuracies" field.
  List<int>? _inaccuracies;
  List<int> get inaccuracies => _inaccuracies ?? const [];
  bool hasInaccuracies() => _inaccuracies != null;

  // "correct" field.
  List<int>? _correct;
  List<int> get correct => _correct ?? const [];
  bool hasCorrect() => _correct != null;

  // "score" field.
  int? _score;
  int get score => _score ?? 0;
  bool hasScore() => _score != null;

  // "resultID" field.
  String? _resultID;
  String get resultID => _resultID ?? '';
  bool hasResultID() => _resultID != null;

  // "wardName" field.
  String? _wardName;
  String get wardName => _wardName ?? '';
  bool hasWardName() => _wardName != null;

  void _initializeFields() {
    _username = snapshotData['username'] as String?;
    _gameName = snapshotData['gameName'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _misses = getDataList(snapshotData['misses']);
    _inaccuracies = getDataList(snapshotData['inaccuracies']);
    _correct = getDataList(snapshotData['correct']);
    _score = castToType<int>(snapshotData['score']);
    _resultID = snapshotData['resultID'] as String?;
    _wardName = snapshotData['wardName'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('results');

  static Stream<ResultsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ResultsRecord.fromSnapshot(s));

  static Future<ResultsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ResultsRecord.fromSnapshot(s));

  static ResultsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ResultsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ResultsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ResultsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ResultsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ResultsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createResultsRecordData({
  String? username,
  String? gameName,
  DateTime? timestamp,
  int? score,
  String? resultID,
  String? wardName,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'username': username,
      'gameName': gameName,
      'timestamp': timestamp,
      'score': score,
      'resultID': resultID,
      'wardName': wardName,
    }.withoutNulls,
  );

  return firestoreData;
}

class ResultsRecordDocumentEquality implements Equality<ResultsRecord> {
  const ResultsRecordDocumentEquality();

  @override
  bool equals(ResultsRecord? e1, ResultsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.username == e2?.username &&
        e1?.gameName == e2?.gameName &&
        e1?.timestamp == e2?.timestamp &&
        listEquality.equals(e1?.misses, e2?.misses) &&
        listEquality.equals(e1?.inaccuracies, e2?.inaccuracies) &&
        listEquality.equals(e1?.correct, e2?.correct) &&
        e1?.score == e2?.score &&
        e1?.resultID == e2?.resultID &&
        e1?.wardName == e2?.wardName;
  }

  @override
  int hash(ResultsRecord? e) => const ListEquality().hash([
        e?.username,
        e?.gameName,
        e?.timestamp,
        e?.misses,
        e?.inaccuracies,
        e?.correct,
        e?.score,
        e?.resultID,
        e?.wardName
      ]);

  @override
  bool isValidKey(Object? o) => o is ResultsRecord;
}
