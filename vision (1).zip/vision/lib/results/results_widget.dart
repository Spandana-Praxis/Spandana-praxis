import '/backend/backend.dart';
import '/components/try_try_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'results_model.dart';
export 'results_model.dart';

class ResultsWidget extends StatefulWidget {
  const ResultsWidget({
    Key? key,
    this.output,
    required this.resultReferenceID,
    this.timeStore,
  }) : super(key: key);

  final dynamic output;
  final DocumentReference? resultReferenceID;
  final int? timeStore;

  @override
  _ResultsWidgetState createState() => _ResultsWidgetState();
}

class _ResultsWidgetState extends State<ResultsWidget> {
  late ResultsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ResultsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Text(
              'Results',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                  ),
            ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 80.0, 0.0, 0.0),
                    child: Container(
                      width: 300.0,
                      height: 300.0,
                      decoration: BoxDecoration(),
                      child: StreamBuilder<ResultsRecord>(
                        stream: ResultsRecord.getDocument(
                            widget.resultReferenceID!),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 50.0,
                                height: 50.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    FlutterFlowTheme.of(context).primary,
                                  ),
                                ),
                              ),
                            );
                          }
                          final gridViewResultsRecord = snapshot.data!;
                          return GridView(
                            padding: EdgeInsets.zero,
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 8,
                              mainAxisSpacing: 1.0,
                              childAspectRatio: 1.0,
                            ),
                            scrollDirection: Axis.vertical,
                            children: [
                              wrapWithModel(
                                model: _model.tryTryModel1,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 1,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel2,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 2,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel3,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 3,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel4,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 4,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel5,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 5,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel6,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 6,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel7,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 7,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel8,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 8,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel9,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 9,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel10,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 10,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel11,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 11,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel12,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 12,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel13,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 13,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel14,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 14,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel15,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 15,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel16,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 16,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel17,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 17,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel18,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 18,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel19,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 19,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel20,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 20,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel21,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 21,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel22,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 22,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel23,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 23,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel24,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 24,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel25,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 25,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel26,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 26,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel27,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 27,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel28,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 28,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel29,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 29,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel30,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 30,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel31,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 31,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel32,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 32,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel33,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 33,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel34,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 34,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel35,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 35,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel36,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 36,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel37,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 37,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel38,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 38,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel39,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 39,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel40,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 40,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel41,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 41,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel42,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 42,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel43,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 43,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel44,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 44,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel45,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 45,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel46,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 46,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel47,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 47,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel48,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 48,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel49,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 49,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel50,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 50,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel51,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 51,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel52,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 52,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel53,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 53,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel54,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 54,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel55,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 55,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel56,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 56,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel57,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 57,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel58,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 58,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel59,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 59,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel60,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 60,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel61,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 61,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel62,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 62,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel63,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 63,
                                ),
                              ),
                              wrapWithModel(
                                model: _model.tryTryModel64,
                                updateCallback: () => setState(() {}),
                                child: TryTryWidget(
                                  misses: gridViewResultsRecord.misses,
                                  inaccuracies:
                                      gridViewResultsRecord.inaccuracies,
                                  correct: gridViewResultsRecord.correct,
                                  selfInt: 64,
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 250.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                100.0, 0.0, 0.0, 0.0),
                            child: Text(
                              'Game Score :',
                              style: FlutterFlowTheme.of(context).bodyMedium,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                10.0, 0.0, 0.0, 0.0),
                            child: Text(
                              getJsonField(
                                widget.output,
                                r'''$.score''',
                              ).toString(),
                              style: FlutterFlowTheme.of(context).bodyMedium,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Align(
                            alignment: AlignmentDirectional(0.0, 0.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  80.0, 0.0, 0.0, 0.0),
                              child: Text(
                                'Completion Time (s) :',
                                style: FlutterFlowTheme.of(context).bodyMedium,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                10.0, 0.0, 0.0, 0.0),
                            child: Text(
                              valueOrDefault<String>(
                                widget.timeStore?.toString(),
                                '213',
                              ),
                              style: FlutterFlowTheme.of(context).bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Text(
                  '*Score calculation metric : (2*correct) - miss - wrong',
                  style: FlutterFlowTheme.of(context).bodyMedium,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
