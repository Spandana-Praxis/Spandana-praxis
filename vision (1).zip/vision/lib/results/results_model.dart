import '/backend/backend.dart';
import '/components/try_try_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'results_widget.dart' show ResultsWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ResultsModel extends FlutterFlowModel<ResultsWidget> {
  ///  Local state fields for this page.

  int? cardID = 1;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for tryTry component.
  late TryTryModel tryTryModel1;
  // Model for tryTry component.
  late TryTryModel tryTryModel2;
  // Model for tryTry component.
  late TryTryModel tryTryModel3;
  // Model for tryTry component.
  late TryTryModel tryTryModel4;
  // Model for tryTry component.
  late TryTryModel tryTryModel5;
  // Model for tryTry component.
  late TryTryModel tryTryModel6;
  // Model for tryTry component.
  late TryTryModel tryTryModel7;
  // Model for tryTry component.
  late TryTryModel tryTryModel8;
  // Model for tryTry component.
  late TryTryModel tryTryModel9;
  // Model for tryTry component.
  late TryTryModel tryTryModel10;
  // Model for tryTry component.
  late TryTryModel tryTryModel11;
  // Model for tryTry component.
  late TryTryModel tryTryModel12;
  // Model for tryTry component.
  late TryTryModel tryTryModel13;
  // Model for tryTry component.
  late TryTryModel tryTryModel14;
  // Model for tryTry component.
  late TryTryModel tryTryModel15;
  // Model for tryTry component.
  late TryTryModel tryTryModel16;
  // Model for tryTry component.
  late TryTryModel tryTryModel17;
  // Model for tryTry component.
  late TryTryModel tryTryModel18;
  // Model for tryTry component.
  late TryTryModel tryTryModel19;
  // Model for tryTry component.
  late TryTryModel tryTryModel20;
  // Model for tryTry component.
  late TryTryModel tryTryModel21;
  // Model for tryTry component.
  late TryTryModel tryTryModel22;
  // Model for tryTry component.
  late TryTryModel tryTryModel23;
  // Model for tryTry component.
  late TryTryModel tryTryModel24;
  // Model for tryTry component.
  late TryTryModel tryTryModel25;
  // Model for tryTry component.
  late TryTryModel tryTryModel26;
  // Model for tryTry component.
  late TryTryModel tryTryModel27;
  // Model for tryTry component.
  late TryTryModel tryTryModel28;
  // Model for tryTry component.
  late TryTryModel tryTryModel29;
  // Model for tryTry component.
  late TryTryModel tryTryModel30;
  // Model for tryTry component.
  late TryTryModel tryTryModel31;
  // Model for tryTry component.
  late TryTryModel tryTryModel32;
  // Model for tryTry component.
  late TryTryModel tryTryModel33;
  // Model for tryTry component.
  late TryTryModel tryTryModel34;
  // Model for tryTry component.
  late TryTryModel tryTryModel35;
  // Model for tryTry component.
  late TryTryModel tryTryModel36;
  // Model for tryTry component.
  late TryTryModel tryTryModel37;
  // Model for tryTry component.
  late TryTryModel tryTryModel38;
  // Model for tryTry component.
  late TryTryModel tryTryModel39;
  // Model for tryTry component.
  late TryTryModel tryTryModel40;
  // Model for tryTry component.
  late TryTryModel tryTryModel41;
  // Model for tryTry component.
  late TryTryModel tryTryModel42;
  // Model for tryTry component.
  late TryTryModel tryTryModel43;
  // Model for tryTry component.
  late TryTryModel tryTryModel44;
  // Model for tryTry component.
  late TryTryModel tryTryModel45;
  // Model for tryTry component.
  late TryTryModel tryTryModel46;
  // Model for tryTry component.
  late TryTryModel tryTryModel47;
  // Model for tryTry component.
  late TryTryModel tryTryModel48;
  // Model for tryTry component.
  late TryTryModel tryTryModel49;
  // Model for tryTry component.
  late TryTryModel tryTryModel50;
  // Model for tryTry component.
  late TryTryModel tryTryModel51;
  // Model for tryTry component.
  late TryTryModel tryTryModel52;
  // Model for tryTry component.
  late TryTryModel tryTryModel53;
  // Model for tryTry component.
  late TryTryModel tryTryModel54;
  // Model for tryTry component.
  late TryTryModel tryTryModel55;
  // Model for tryTry component.
  late TryTryModel tryTryModel56;
  // Model for tryTry component.
  late TryTryModel tryTryModel57;
  // Model for tryTry component.
  late TryTryModel tryTryModel58;
  // Model for tryTry component.
  late TryTryModel tryTryModel59;
  // Model for tryTry component.
  late TryTryModel tryTryModel60;
  // Model for tryTry component.
  late TryTryModel tryTryModel61;
  // Model for tryTry component.
  late TryTryModel tryTryModel62;
  // Model for tryTry component.
  late TryTryModel tryTryModel63;
  // Model for tryTry component.
  late TryTryModel tryTryModel64;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    tryTryModel1 = createModel(context, () => TryTryModel());
    tryTryModel2 = createModel(context, () => TryTryModel());
    tryTryModel3 = createModel(context, () => TryTryModel());
    tryTryModel4 = createModel(context, () => TryTryModel());
    tryTryModel5 = createModel(context, () => TryTryModel());
    tryTryModel6 = createModel(context, () => TryTryModel());
    tryTryModel7 = createModel(context, () => TryTryModel());
    tryTryModel8 = createModel(context, () => TryTryModel());
    tryTryModel9 = createModel(context, () => TryTryModel());
    tryTryModel10 = createModel(context, () => TryTryModel());
    tryTryModel11 = createModel(context, () => TryTryModel());
    tryTryModel12 = createModel(context, () => TryTryModel());
    tryTryModel13 = createModel(context, () => TryTryModel());
    tryTryModel14 = createModel(context, () => TryTryModel());
    tryTryModel15 = createModel(context, () => TryTryModel());
    tryTryModel16 = createModel(context, () => TryTryModel());
    tryTryModel17 = createModel(context, () => TryTryModel());
    tryTryModel18 = createModel(context, () => TryTryModel());
    tryTryModel19 = createModel(context, () => TryTryModel());
    tryTryModel20 = createModel(context, () => TryTryModel());
    tryTryModel21 = createModel(context, () => TryTryModel());
    tryTryModel22 = createModel(context, () => TryTryModel());
    tryTryModel23 = createModel(context, () => TryTryModel());
    tryTryModel24 = createModel(context, () => TryTryModel());
    tryTryModel25 = createModel(context, () => TryTryModel());
    tryTryModel26 = createModel(context, () => TryTryModel());
    tryTryModel27 = createModel(context, () => TryTryModel());
    tryTryModel28 = createModel(context, () => TryTryModel());
    tryTryModel29 = createModel(context, () => TryTryModel());
    tryTryModel30 = createModel(context, () => TryTryModel());
    tryTryModel31 = createModel(context, () => TryTryModel());
    tryTryModel32 = createModel(context, () => TryTryModel());
    tryTryModel33 = createModel(context, () => TryTryModel());
    tryTryModel34 = createModel(context, () => TryTryModel());
    tryTryModel35 = createModel(context, () => TryTryModel());
    tryTryModel36 = createModel(context, () => TryTryModel());
    tryTryModel37 = createModel(context, () => TryTryModel());
    tryTryModel38 = createModel(context, () => TryTryModel());
    tryTryModel39 = createModel(context, () => TryTryModel());
    tryTryModel40 = createModel(context, () => TryTryModel());
    tryTryModel41 = createModel(context, () => TryTryModel());
    tryTryModel42 = createModel(context, () => TryTryModel());
    tryTryModel43 = createModel(context, () => TryTryModel());
    tryTryModel44 = createModel(context, () => TryTryModel());
    tryTryModel45 = createModel(context, () => TryTryModel());
    tryTryModel46 = createModel(context, () => TryTryModel());
    tryTryModel47 = createModel(context, () => TryTryModel());
    tryTryModel48 = createModel(context, () => TryTryModel());
    tryTryModel49 = createModel(context, () => TryTryModel());
    tryTryModel50 = createModel(context, () => TryTryModel());
    tryTryModel51 = createModel(context, () => TryTryModel());
    tryTryModel52 = createModel(context, () => TryTryModel());
    tryTryModel53 = createModel(context, () => TryTryModel());
    tryTryModel54 = createModel(context, () => TryTryModel());
    tryTryModel55 = createModel(context, () => TryTryModel());
    tryTryModel56 = createModel(context, () => TryTryModel());
    tryTryModel57 = createModel(context, () => TryTryModel());
    tryTryModel58 = createModel(context, () => TryTryModel());
    tryTryModel59 = createModel(context, () => TryTryModel());
    tryTryModel60 = createModel(context, () => TryTryModel());
    tryTryModel61 = createModel(context, () => TryTryModel());
    tryTryModel62 = createModel(context, () => TryTryModel());
    tryTryModel63 = createModel(context, () => TryTryModel());
    tryTryModel64 = createModel(context, () => TryTryModel());
  }

  void dispose() {
    unfocusNode.dispose();
    tryTryModel1.dispose();
    tryTryModel2.dispose();
    tryTryModel3.dispose();
    tryTryModel4.dispose();
    tryTryModel5.dispose();
    tryTryModel6.dispose();
    tryTryModel7.dispose();
    tryTryModel8.dispose();
    tryTryModel9.dispose();
    tryTryModel10.dispose();
    tryTryModel11.dispose();
    tryTryModel12.dispose();
    tryTryModel13.dispose();
    tryTryModel14.dispose();
    tryTryModel15.dispose();
    tryTryModel16.dispose();
    tryTryModel17.dispose();
    tryTryModel18.dispose();
    tryTryModel19.dispose();
    tryTryModel20.dispose();
    tryTryModel21.dispose();
    tryTryModel22.dispose();
    tryTryModel23.dispose();
    tryTryModel24.dispose();
    tryTryModel25.dispose();
    tryTryModel26.dispose();
    tryTryModel27.dispose();
    tryTryModel28.dispose();
    tryTryModel29.dispose();
    tryTryModel30.dispose();
    tryTryModel31.dispose();
    tryTryModel32.dispose();
    tryTryModel33.dispose();
    tryTryModel34.dispose();
    tryTryModel35.dispose();
    tryTryModel36.dispose();
    tryTryModel37.dispose();
    tryTryModel38.dispose();
    tryTryModel39.dispose();
    tryTryModel40.dispose();
    tryTryModel41.dispose();
    tryTryModel42.dispose();
    tryTryModel43.dispose();
    tryTryModel44.dispose();
    tryTryModel45.dispose();
    tryTryModel46.dispose();
    tryTryModel47.dispose();
    tryTryModel48.dispose();
    tryTryModel49.dispose();
    tryTryModel50.dispose();
    tryTryModel51.dispose();
    tryTryModel52.dispose();
    tryTryModel53.dispose();
    tryTryModel54.dispose();
    tryTryModel55.dispose();
    tryTryModel56.dispose();
    tryTryModel57.dispose();
    tryTryModel58.dispose();
    tryTryModel59.dispose();
    tryTryModel60.dispose();
    tryTryModel61.dispose();
    tryTryModel62.dispose();
    tryTryModel63.dispose();
    tryTryModel64.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
