import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'results_copy_model.dart';
export 'results_copy_model.dart';

class ResultsCopyWidget extends StatefulWidget {
  const ResultsCopyWidget({
    Key? key,
    this.output,
    required this.resultReference,
  }) : super(key: key);

  final dynamic output;
  final DocumentReference? resultReference;

  @override
  _ResultsCopyWidgetState createState() => _ResultsCopyWidgetState();
}

class _ResultsCopyWidgetState extends State<ResultsCopyWidget> {
  late ResultsCopyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ResultsCopyModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      setState(() {
        _model.resultsRef = ReferenceFromJsonStruct.maybeFromMap(getJsonField(
          widget.output,
          r'''$.resultRef''',
        ))?.referenceID;
      });
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Text(
              'Results',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                  ),
            ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  valueOrDefault<String>(
                    widget.output?.toString(),
                    'The function suceeded but JSON isn\'t displayed',
                  ),
                  style: FlutterFlowTheme.of(context).bodyMedium,
                ),
                Expanded(
                  child: Container(
                    width: 300.0,
                    height: 300.0,
                    decoration: BoxDecoration(),
                    child: StreamBuilder<ResultsRecord>(
                      stream:
                          ResultsRecord.getDocument(widget.resultReference!),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  FlutterFlowTheme.of(context).primary,
                                ),
                              ),
                            ),
                          );
                        }
                        final gridViewResultsRecord = snapshot.data!;
                        return GridView(
                          padding: EdgeInsets.zero,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 8,
                            crossAxisSpacing: 10.0,
                            mainAxisSpacing: 10.0,
                            childAspectRatio: 1.0,
                          ),
                          scrollDirection: Axis.vertical,
                          children: [
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(1, 1))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(2, 2))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(2, 2))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(2, 2))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(3, 3))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(3, 3))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(3, 3))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(4, 4))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(4, 4))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(4, 4))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(5, 5))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(5, 5))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(5, 5))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(6, 6))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(6, 6))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(6, 6))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(7, 7))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(7, 7))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(7, 7))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(8, 8))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(8, 8))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(8, 8))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(9, 9))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(9, 9))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(9, 9))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(10, 10))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(random_data.randomInteger(
                                            10, 10))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(random_data.randomInteger(
                                            10, 10))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(11, 11))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(random_data.randomInteger(
                                            11, 11))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(random_data.randomInteger(
                                            11, 11))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(1, 1))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(1, 1))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(1, 1))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(1, 1))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                            Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: valueOrDefault<Color>(
                                  () {
                                    if (gridViewResultsRecord.misses.contains(
                                        random_data.randomInteger(1, 1))) {
                                      return Color(0xA6E93EE5);
                                    } else if (gridViewResultsRecord
                                        .inaccuracies
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFFB31414);
                                    } else if (gridViewResultsRecord.correct
                                        .contains(
                                            random_data.randomInteger(1, 1))) {
                                      return Color(0xFF50E02E);
                                    } else {
                                      return Color(0xFF0F3948);
                                    }
                                  }(),
                                  Color(0xFF0F3948),
                                ),
                                borderRadius: BorderRadius.circular(5.0),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          100.0, 0.0, 0.0, 230.0),
                      child: Text(
                        'Game Score : ',
                        style: FlutterFlowTheme.of(context).bodyMedium,
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            10.0, 0.0, 0.0, 230.0),
                        child: Text(
                          getJsonField(
                            widget.output,
                            r'''$.score''',
                          ).toString(),
                          style: FlutterFlowTheme.of(context).bodyMedium,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
