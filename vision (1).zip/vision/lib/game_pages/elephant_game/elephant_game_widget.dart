import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/custom_cloud_functions/custom_cloud_function_response_manager.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'elephant_game_model.dart';
export 'elephant_game_model.dart';

class ElephantGameWidget extends StatefulWidget {
  const ElephantGameWidget({
    Key? key,
    required this.selectedDifficulty,
    required this.selectedDocumentID,
    required this.selectedGame,
  }) : super(key: key);

  final int? selectedDifficulty;
  final DocumentReference? selectedDocumentID;
  final String? selectedGame;

  @override
  _ElephantGameWidgetState createState() => _ElephantGameWidgetState();
}

class _ElephantGameWidgetState extends State<ElephantGameWidget> {
  late ElephantGameModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ElephantGameModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Text(
              'Minesotta Dexterity Test',
              textAlign: TextAlign.center,
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                  ),
            ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 120.0, 0.0, 0.0),
                    child: Container(
                      width: 300.0,
                      height: 300.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: StreamBuilder<TestRecord>(
                        stream:
                            TestRecord.getDocument(widget.selectedDocumentID!),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 50.0,
                                height: 50.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    FlutterFlowTheme.of(context).primary,
                                  ),
                                ),
                              ),
                            );
                          }
                          final gridViewTestRecord = snapshot.data!;
                          return GridView(
                            padding: EdgeInsets.zero,
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 8,
                              crossAxisSpacing: 1.0,
                              mainAxisSpacing: 1.0,
                              childAspectRatio: 1.0,
                            ),
                            scrollDirection: Axis.vertical,
                            children: [
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(1, 1),
                                          1,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(2, 2),
                                          1,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(3, 3),
                                          3,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(4, 4),
                                          4,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(5, 5),
                                          5,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(6, 6),
                                          6,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(7, 7),
                                          7,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(8, 8),
                                          8,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(9, 9),
                                          9,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(random_data.randomInteger(
                                                10, 10))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(11, 11),
                                          11,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(12, 12),
                                          12,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(13, 13),
                                          13,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(14, 14),
                                          14,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(15, 15),
                                          15,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(16, 16),
                                          16,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(17, 17),
                                          17,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(18, 18),
                                          18,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(19, 19),
                                          19,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(20, 20),
                                          20,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(21, 21),
                                          21,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(22, 22),
                                          22,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(23, 23),
                                          23,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(24, 24),
                                          24,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(25, 25),
                                          25,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(26, 26),
                                          26,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(27, 27),
                                          27,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(28, 28),
                                          28,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(29, 29),
                                          29,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(30, 30),
                                          30,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(31, 31),
                                          31,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(32, 32),
                                          32,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(33, 33),
                                          33,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(34, 34),
                                          34,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(35, 35),
                                          35,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(36, 36),
                                          36,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(37, 37),
                                          37,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(38, 38),
                                          38,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(39, 39),
                                          39,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(40, 40),
                                          40,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(41, 41),
                                          41,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(42, 42),
                                          42,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(43, 43),
                                          43,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(44, 44),
                                          44,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(45, 45),
                                          45,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(46, 46),
                                          46,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(47, 47),
                                          47,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(48, 48),
                                          48,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(49, 49),
                                          49,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(50, 50),
                                          50,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(51, 51),
                                          51,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(52, 52),
                                          52,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(53, 53),
                                          53,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(54, 54),
                                          54,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(55, 55),
                                          55,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(56, 56),
                                          56,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(57, 57),
                                          57,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(58, 58),
                                          58,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(59, 59),
                                          59,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(60, 60),
                                          60,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(61, 61),
                                          61,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(62, 62),
                                          62,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(63, 63),
                                          63,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              Card(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                color: _model.buttonTap &&
                                        gridViewTestRecord.patternElements
                                            .contains(valueOrDefault<int>(
                                          random_data.randomInteger(64, 64),
                                          64,
                                        ))
                                    ? Color(0xFF1DCDC3)
                                    : Color(0xFF1A1309),
                                elevation: 4.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                  child: StreamBuilder<TestRecord>(
                    stream: TestRecord.getDocument(widget.selectedDocumentID!),
                    builder: (context, snapshot) {
                      // Customize what your widget looks like when it's loading.
                      if (!snapshot.hasData) {
                        return Center(
                          child: SizedBox(
                            width: 50.0,
                            height: 50.0,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                FlutterFlowTheme.of(context).primary,
                              ),
                            ),
                          ),
                        );
                      }
                      final columnTestRecord = snapshot.data!;
                      return Builder(
                        builder: (context) {
                          final element =
                              columnTestRecord.patternElements.toList();
                          return Column(
                            mainAxisSize: MainAxisSize.max,
                            children:
                                List.generate(element.length, (elementIndex) {
                              final elementItem = element[elementIndex];
                              return Text(
                                _model.buttonTap
                                    ? elementItem.toString()
                                    : '- -',
                                style: FlutterFlowTheme.of(context).bodyMedium,
                              );
                            }),
                          );
                        },
                      );
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                  child: InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onLongPress: () async {
                      _model.timerController.onResetTimer();

                      _model.timeStore = _model.timerMilliseconds;
                      try {
                        final result = await FirebaseFunctions.instanceFor(
                                region: 'us-central1')
                            .httpsCallable('compareArrays')
                            .call({
                          "documentRef": widget.selectedDocumentID?.id,
                          "username": currentUserDisplayName,
                          "gameName": widget.selectedGame,
                          "timeScore": _model.timeStore,
                          "wardName": FFAppState().wardName,
                        });
                        _model.cloudFunctionOutput =
                            CompareArraysCloudFunctionCallResponse(
                          data: result.data,
                          succeeded: true,
                          resultAsString: result.data.toString(),
                          jsonBody: result.data,
                        );
                      } on FirebaseFunctionsException catch (error) {
                        _model.cloudFunctionOutput =
                            CompareArraysCloudFunctionCallResponse(
                          errorCode: error.code,
                          succeeded: false,
                        );
                      }

                      if (_model.cloudFunctionOutput!.succeeded!) {
                        if (getJsonField(
                          _model.cloudFunctionOutput!.jsonBody,
                          r'''$.done''',
                        )) {
                          _model.resultReference = await queryResultsRecordOnce(
                            queryBuilder: (resultsRecord) =>
                                resultsRecord.where(
                              'resultID',
                              isEqualTo: getJsonField(
                                _model.cloudFunctionOutput?.jsonBody,
                                r'''$.resultRef''',
                              ).toString(),
                            ),
                            singleRecord: true,
                          ).then((s) => s.firstOrNull);

                          context.pushNamed(
                            'Results',
                            queryParameters: {
                              'output': serializeParam(
                                _model.cloudFunctionOutput?.jsonBody,
                                ParamType.JSON,
                              ),
                              'resultReferenceID': serializeParam(
                                _model.resultReference?.reference,
                                ParamType.DocumentReference,
                              ),
                              'timeStore': serializeParam(
                                _model.timeStore,
                                ParamType.int,
                              ),
                            }.withoutNulls,
                          );
                        } else {
                          setState(() {
                            _model.message =
                                '\"Please press STOP on the board before checking results\"';
                          });
                        }
                      } else {
                        context.pushNamed(
                          'somethingWentWrong',
                          queryParameters: {
                            'errorReson': serializeParam(
                              _model.cloudFunctionOutput?.errorCode,
                              ParamType.String,
                            ),
                          }.withoutNulls,
                        );
                      }

                      setState(() {});
                    },
                    child: FFButtonWidget(
                      onPressed: () async {
                        setState(() {
                          _model.buttonTap = true;
                          _model.buttonState = 'Check Pattern';
                        });
                        _model.timerController.onStartTimer();
                        _model.apiResultw86 = await StartSignalCall.call(
                          username: currentUserDisplayName,
                          wardName: FFAppState().wardName,
                        );
                        if (!(_model.apiResultw86?.succeeded ?? true)) {
                          context.pushNamed('somethingWentWrong');
                        }

                        setState(() {});
                      },
                      text: _model.buttonState,
                      options: FFButtonOptions(
                        height: 40.0,
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 0.0, 24.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: FlutterFlowTheme.of(context).primary,
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.white,
                                ),
                        elevation: 3.0,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                ),
                Text(
                  _model.message,
                  style: FlutterFlowTheme.of(context).bodyMedium,
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                  child: FlutterFlowTimer(
                    initialTime: _model.timerMilliseconds,
                    getDisplayTime: (value) => StopWatchTimer.getDisplayTime(
                      value,
                      hours: false,
                      milliSecond: false,
                    ),
                    controller: _model.timerController,
                    updateStateInterval: Duration(milliseconds: 1000),
                    onChanged: (value, displayTime, shouldUpdate) {
                      _model.timerMilliseconds = value;
                      _model.timerValue = displayTime;
                      if (shouldUpdate) setState(() {});
                    },
                    textAlign: TextAlign.start,
                    style: FlutterFlowTheme.of(context).headlineSmall,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
