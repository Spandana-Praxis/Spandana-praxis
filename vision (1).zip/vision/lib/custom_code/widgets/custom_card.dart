// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

class CustomCard extends StatefulWidget {
  const CustomCard({
    Key? key,
    required this.width,
    required this.height,
    required this.color,
    required this.borderRadius,
    required this.elevation,
    this.selfInteger,
  }) : super(key: key);

  final double width;
  final double height;
  final Color color;
  final double borderRadius;
  final double elevation;
  final int? selfInteger; // Additional property

  @override
  _CustomCardState createState() => _CustomCardState();
}

class _CustomCardState extends State<CustomCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      height: widget.height,
      child: Card(
        color: widget.color,
        elevation: widget.elevation,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(widget.borderRadius),
        ),
        child: Column(
          children: [
            // Your card content goes here
            Text('Custom Card'),
            // Additional content using selfInteger
            Text('Self Integer: ${widget.selfInteger ?? 0}'),
          ],
        ),
      ),
    );
  }
}
