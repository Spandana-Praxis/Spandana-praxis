import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'card_with_property_model.dart';
export 'card_with_property_model.dart';

class CardWithPropertyWidget extends StatefulWidget {
  const CardWithPropertyWidget({Key? key}) : super(key: key);

  @override
  _CardWithPropertyWidgetState createState() => _CardWithPropertyWidgetState();
}

class _CardWithPropertyWidgetState extends State<CardWithPropertyWidget> {
  late CardWithPropertyModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CardWithPropertyModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Card(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      color: Color(0xFF1A1309),
      elevation: 8.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4.0),
      ),
    );
  }
}
