import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'try_try_model.dart';
export 'try_try_model.dart';

class TryTryWidget extends StatefulWidget {
  const TryTryWidget({
    Key? key,
    required this.misses,
    required this.inaccuracies,
    required this.correct,
    required this.selfInt,
  }) : super(key: key);

  final List<int>? misses;
  final List<int>? inaccuracies;
  final List<int>? correct;
  final int? selfInt;

  @override
  _TryTryWidgetState createState() => _TryTryWidgetState();
}

class _TryTryWidgetState extends State<TryTryWidget> {
  late TryTryModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TryTryModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Card(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      color: valueOrDefault<Color>(
        () {
          if (widget.misses!.contains(widget.selfInt)) {
            return Color(0xA6E93EE5);
          } else if (widget.inaccuracies!.contains(widget.selfInt)) {
            return Color(0xFFB31414);
          } else if (widget.correct!.contains(widget.selfInt)) {
            return Color(0xFF50E02E);
          } else {
            return Color(0xFF1A1309);
          }
        }(),
        Color(0xFF1A1309),
      ),
      elevation: 7.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4.0),
      ),
    );
  }
}
